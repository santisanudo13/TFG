/*
 * @brief Basic function to read a value from register
 * @param file: File used to keep the i2c communication between camera and working station.
 * @param reg: register to read
 * @return Success: Will return byte read .Error: Return -1
 */
int i2c_read(int file, int reg);

/*
 * @brief Basic function to write data into a register
 * @param file: File used to keep the i2c communication between camera and working station.
 * @param reg: register to write
 * @param value: value that will be written in specified register
 * @return Success: Will return byte written. Error: -1
 */
int i2c_write(int file, int reg, int value);

/*
 * @brief Function used to initialize camera which is placed in specific address
 * Before using any other functions, we must use this one first.
 * @param address: address where camera is working
 * @param portNumber: port number where camera is conected.
 * @return Success: 0 Error: -1
 */
int i2c_init(int address, int portNumber); //return
