#include "altoNivel.h"

int file; //Esto como ponerlo

int camera_init(int address, int port) {
	file = i2c_init();
	return file;
}

void camera_change_address(int newAddress) {
	i2c_write(file, COMMAND_REGISTER, 0xA0);
	i2c_write(file, COMMAND_REGISTER, 0xAA);
	i2c_write(file, COMMAND_REGISTER, 0xA5);
	i2c_write(file, COMMAND_REGISTER, newAddress);
}

int camera_objects_detected() {
	if (file < 0) {
		return -1;
	}
	return i2c_read(file, OBJECTS_DETECTED_REGISTER);

}

void camera_software_version(char *buffer) {
	int j = 0;
	int i;
	for (i = SOFTWARE_VERSION_REGISTER_BASE; i <= SOFTWARE_VERSION_REGISTER_TOP;
			i++) {
		buffer[j] = i2c_read(file, i);
		j++;
	}
}

void camera_vendor_id(char *buffer) {
	int j = 0;
	int i;
	for (i = VENDOR_ID_REGISTER_BASE; i <= VENDOR_ID_REGISTER_TOP; i++) {
		buffer[j] = i2c_read(file, i);
		j++;
	}
}

void camera_device_id(char *buffer) {
	int j = 0;
	int i;
	for (i = DEVICE_ID_REGISTER_BASE; i <= DEVICE_ID_REGISTER_TOP; i++) {
		buffer[j] = i2c_read(file, i);
		j++;
	}
}

int camera_start_Tracking() {
	if (file < 0) {
		return -1;
	}
	return i2c_write(file, COMMAND_REGISTER, START_TRACK_COMMAND);
}

int camera_stop_tracking() {
	if (file < 0) {
		return -1;
	}
	return i2c_write(file, COMMAND_REGISTER, STOP_TRACK_COMMAND);
}

int camera_reset() {
	if (file < 0) {
		return -1;
	}
	return i2c_write(file, COMMAND_REGISTER, RESET_COMMAND);
}

int camera_object_coordinates(int object, object_properties_t data) {
	int base_register = OBJECT_BASE + (object * 5); //Calculamos el registro base de ese objeto

	data.color = i2c_read(file, base_register);
	data.x_upper_left = i2c_read(file, base_register + 1);
	data.y_upper_left = i2c_read(file, base_register + 2);
	data.x_lower_right = i2c_read(file, base_register + 3);
	data.y_lower_right = i2c_read(file, base_register + 4);

	if (data.x_upper_left == -1 || data.y_upper_left == -1
			|| data.x_lower_right == -1 || data.y_lower_right == -1) {
		return -1;
	}

	return 0;
}

int camera_sort_objects(int mode) {

	switch (mode) {
	case 0:
		return i2c_write(file, COMMAND_REGISTER, SORT_SIZE_COMMAND);

	case 1:
		return i2c_write(file, COMMAND_REGISTER, SORT_COLOR_COMMAND);

	case 2:
		return i2c_write(file, COMMAND_REGISTER, NO_SORT_COMMAND);

	default:
		return -1;
	}

}

