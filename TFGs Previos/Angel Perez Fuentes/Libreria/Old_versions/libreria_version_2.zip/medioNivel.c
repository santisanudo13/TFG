#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "i2c-tools.h"

int i2c_read(int file, int reg) {
	return i2c_smbus_read_byte_data(file, reg);
}

int i2c_write(int file, int reg, int value) {
	return i2c_smbus_write_byte_data(file, reg, value);
}

int i2c_init(int address, int portNumber) {
	int file;
	int portAdded = portNumber +2;
	char port[1];
	snprintf(port,10,"%d", portAdded);
	char* base= "/dev/i2c-";
	strcat(base,port);

	file = open(base, O_RDWR);

	if (file < 0) {
		printf("No he podido abrir el file\n");
		return -1;
	}

	int addr = address; //I2C ADDRESS

	if (ioctl(file, I2C_SLAVE, addr) < 0) {
		printf("Fallo al cambiar la direccion del I2C_SLAVE\n");
		return -1;
	}
	return file;
}
